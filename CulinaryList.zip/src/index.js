import "regenerator-runtime";
import "./style/styles.css";
import "./script/component/nav-bar.js";
import main from "./script/view/main.js";

document.addEventListener("DOMContentLoaded", main);